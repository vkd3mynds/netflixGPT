import React from 'react'

const SecondaryContainer = () => {
  return (
    <div>SecondaryContainer</div>
  )
}

export default SecondaryContainer