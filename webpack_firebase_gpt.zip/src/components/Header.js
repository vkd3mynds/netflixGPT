import React from 'react'
import { LOGO } from '../utils/Constrants'

const Header = () => {
  return (
    <div className='absolute z-10 py-2 bg-gradient-to-b from-black'>
      <img src={LOGO} alt="logo"  className='w-44'/>
    </div>
  )
}

export default Header