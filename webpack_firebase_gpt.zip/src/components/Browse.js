import React from 'react';
import Header from './Header';

const Browse = () => {
  return (
    <>
      <Header />
      <div>Main Page</div>
    </>
  );
}

export default Browse;
