import React from 'react';
import { LOGO ,USER_AVATAR} from '../utils/Constrants';
import {  signOut } from "firebase/auth";
import { auth } from '../utils/firebase';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Browse = () => {

  const navigate = useNavigate()
  const user = useSelector(store => store.user)
  const handleSignOut = ()=>{
    signOut(auth).then(() => {
      
      navigate('/')
      // Sign-out successful.
    }).catch((error) => {
      // An error happened.
      navigate("/error")
    });
    
  }
  return (
    <>
      <div className='z-10 py-2 bg-gradient-to-b from-black flex justify-between'>
      <img src={LOGO} alt="logo"  className='w-44'/>
      <div className='z-10 py-2 '>
      <img src={user?.photoURL} alt="logo"  className=''/>
      <button className='bg-red-700 p-2' onClick={handleSignOut}>Sign Out</button>
    </div>
    </div>
      
      <div>Main Page</div>
    </>
  );
}

export default Browse;
